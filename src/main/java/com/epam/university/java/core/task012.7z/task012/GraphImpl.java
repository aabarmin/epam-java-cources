package com.epam.university.java.core.task012;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Some text.
 */
public class GraphImpl implements Graph {
    private Map<Integer, HashSet<Integer>> edgeRepository = new HashMap<>();
    private int vertexesCount;

    public GraphImpl(int vertexesCount) {
        if (vertexesCount == 0) {
            throw new IllegalArgumentException();
        }
        this.vertexesCount = vertexesCount;
        while (vertexesCount > 0) {
            edgeRepository.put(vertexesCount, new HashSet<>());
            vertexesCount--;
        }
        System.out.println(edgeRepository);
    }

    @Override
    public void createEdge(int from, int to) {
        if (edgeRepository.containsKey(from)) {
            edgeRepository.get(from).add(to);
        } else {
            HashSet<Integer> temp = new HashSet<>();
            temp.add(to);
            edgeRepository.put(from, temp);
        }

        if (edgeRepository.containsKey(to)) {
            edgeRepository.get(to).add(from);
        } else {
            HashSet<Integer> temp = new HashSet<>();
            temp.add(from);
            edgeRepository.put(to, temp);
        }
    }

    @Override
    public boolean edgeExists(int from, int to) {
        if (edgeRepository.containsKey(from)) {
            for (Integer i: edgeRepository.get(from)
                 ) {
                if (i.equals(to)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public void removeEdge(int from, int to) {
        if (edgeRepository.containsKey(from)) {
            edgeRepository.get(from).remove(to);
        }
    }

    @Override
    public Collection<Integer> getAdjacent(int from) {
        if (edgeRepository.containsKey(from)) {
            return edgeRepository.get(from);
        }
        return null;
    }
}
